

<br/><hr>    <hr>
A share of <?=$_POST["name"]?> (<?=$_POST["symbol"]?>) costs <strong>$<?=number_format($_POST["price"], 2)?></strong>

<br/><br/><br/><br/><hr>    <hr>
<ul class="menu">
   <a href="index.php">  Portfolio  </a> *
    <a href="quote.php">  Quote  </a> *
    <a href="buy.php">  Buy  </a> *
    <a href="sell.php">  Sell  </a> *
    <a href="history.php">  History  </a> *
    <a href="changepw.php">  ChangePW  </a> *
    <a href="logout.php"><strong>  Log Out  </strong></a>
</ul>



